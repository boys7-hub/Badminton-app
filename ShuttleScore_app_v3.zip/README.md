# ShuttleScore

Android app (Kotlin, Jetpack Compose, CameraX, Media3), landscape, works offline.

## What it does
- Manual scoreboard with BWF rules (21 points, win by 2, cap 30, best of 3), undo.
- Live camera recording to Movies/ShuttleScore.
- Phone-to-phone score mirroring (Nearby Connections, no internet or router).
- AI scoring (needs calibration, then "AI: ON"):
  - Detects the white shuttle by motion + brightness, draws its yellow trail.
  - When the shuttle disappears, works out where it landed (court position), who hit last,
    and awards the point automatically if confident. Close or unclear calls show
    "AI unsure" with A wins / B wins / Skip. Undo always works.
- "Export score video": re-encodes the recording with the score burned into the top-left corner
  and saves it to Movies/ShuttleScore (offline, on the phone, takes a few minutes).

## Calibration (once per tripod position)
1. Pick View: Behind or Side, and Singles or Doubles.
2. Tap Calibrate, then tap the four OUTER court corners in this order:
   side A back corner 1, side A back corner 2 (same back line),
   side B corner on the same sideline as corner 2, side B corner on the same sideline as corner 1.
   (Side A = the team your "+1 A" button counts.)
3. A green outline appears. Tap "AI: OFF" to turn AI on.
Do not move the phone after calibrating. Use a tripod, ideally high and behind the court.

## Get the APK without a PC (cloud build)
1. Create a free GitHub account and a new empty repository.
2. Upload this whole folder, keeping the structure (including `.github/workflows/build.yml`).
3. Repository > Actions > "Build APK" > Run workflow (it also runs on every upload).
4. Open the finished run, download the artifact "ShuttleScore-debug-apk", unzip, install app-debug.apk.
Or open the folder in Android Studio and press Run.

## Honest status
- NOT yet compiled and NOT yet run on a phone. Expect small build errors on the first cloud build.
- Tested on the computer with synthetic data only: scoring rules, court calibration maths,
  shuttle blob detection, rally tracking and the point decision (see `tests/`).
- The shuttle detector is a simple motion/brightness detector, not a trained neural network.
  Real accuracy is unknown until it is tried on your hall and lighting. Bright lights, white
  shirts moving, and shuttles hidden by players will cause misses; those cases fall back to
  "AI unsure" or no point. Tuning needs your recorded match clips.
- The landing position is the last place the shuttle was seen. If a player hides the landing,
  the call can be wrong.
- Burn-in overlay size and position use Media3 defaults and are unverified; adjust
  `ScoreOverlay` in OverlayExporter.kt if the scoreboard looks too big or small.
- Serve-specific lines (the shorter doubles serve boundary) are not modelled; only the normal court lines.
- Not built yet: smash speed, shot classification, player tracking, heatmap.
