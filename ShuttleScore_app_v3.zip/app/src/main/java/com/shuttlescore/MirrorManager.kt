package com.shuttlescore

import android.content.Context
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsStatusCodes
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import com.shuttlescore.core.GameState

/**
 * Mirrors the score to other phones with no internet and no router.
 * The scorer phone advertises; viewer phones discover it and connect.
 * Uses Bluetooth/Wi-Fi Direct through Google Play services (Nearby Connections).
 */
class MirrorManager(
    context: Context,
    private val currentState: () -> GameState,
    private val onState: (GameState) -> Unit,
    private val onStatus: (String) -> Unit
) {
    private val client = Nearby.getConnectionsClient(context.applicationContext)
    private val connected = mutableSetOf<String>()
    private var isScorer = false

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            val bytes = payload.asBytes() ?: return
            decodeGameState(String(bytes))?.let(onState)
        }

        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) = Unit
    }

    private val connectionCallback = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            client.acceptConnection(endpointId, payloadCallback)
        }

        override fun onConnectionResult(endpointId: String, result: ConnectionResolution) {
            if (result.status.statusCode == ConnectionsStatusCodes.STATUS_OK) {
                connected.add(endpointId)
                onStatus("Connected (${connected.size})")
                if (isScorer) {
                    // Bring a newly connected phone up to date straight away.
                    send(currentState())
                } else {
                    client.stopDiscovery()
                }
            } else {
                onStatus("Connection failed, retrying")
            }
        }

        override fun onDisconnected(endpointId: String) {
            connected.remove(endpointId)
            onStatus(if (connected.isEmpty()) "Disconnected" else "Connected (${connected.size})")
            if (!isScorer && connected.isEmpty()) startViewer()
        }
    }

    private val discoveryCallback = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            onStatus("Scorer found, connecting")
            client.requestConnection("Viewer", endpointId, connectionCallback)
        }

        override fun onEndpointLost(endpointId: String) {
            onStatus("Searching for scorer")
        }
    }

    fun startScorer() {
        isScorer = true
        val options = AdvertisingOptions.Builder().setStrategy(Strategy.P2P_STAR).build()
        client.startAdvertising("Scorer", SERVICE_ID, connectionCallback, options)
            .addOnSuccessListener { onStatus("Waiting for viewers") }
            .addOnFailureListener { onStatus("Mirror failed: ${it.message}") }
    }

    fun startViewer() {
        isScorer = false
        val options = DiscoveryOptions.Builder().setStrategy(Strategy.P2P_STAR).build()
        client.startDiscovery(SERVICE_ID, discoveryCallback, options)
            .addOnSuccessListener { onStatus("Searching for scorer") }
            .addOnFailureListener { onStatus("Search failed: ${it.message}") }
    }

    fun send(state: GameState) {
        if (connected.isEmpty()) return
        client.sendPayload(connected.toList(), Payload.fromBytes(state.encode().toByteArray()))
    }

    fun stop() {
        client.stopAdvertising()
        client.stopDiscovery()
        client.stopAllEndpoints()
        connected.clear()
    }

    private companion object {
        const val SERVICE_ID = "com.shuttlescore.mirror"
    }
}
