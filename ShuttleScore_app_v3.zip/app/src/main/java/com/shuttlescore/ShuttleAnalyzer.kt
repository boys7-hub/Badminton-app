package com.shuttlescore

import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.shuttlescore.core.Pt
import com.shuttlescore.core.ShuttleDetector

/**
 * Feeds camera frames to the shuttle detector. Runs on the analysis thread.
 * Assumes landscape (the app is locked to landscape), so image coordinates match the preview.
 */
class ShuttleAnalyzer(
    private val enabled: () -> Boolean,
    private val predictor: () -> Pt?,
    private val onFrame: (tMs: Long, shuttle: Pt?) -> Unit
) : ImageAnalysis.Analyzer {
    private val detector = ShuttleDetector()
    private var compact = ByteArray(0)

    override fun analyze(image: ImageProxy) {
        try {
            if (!enabled()) {
                detector.reset()
                return
            }
            val plane = image.planes[0]
            val w = image.width
            val h = image.height
            if (compact.size != w * h) compact = ByteArray(w * h)

            val buf = plane.buffer
            val rowStride = plane.rowStride
            for (row in 0 until h) {
                buf.position(row * rowStride)
                buf.get(compact, row * w, w)
            }

            var p = detector.detect(compact, w, h, predictor())
            if (p != null && image.imageInfo.rotationDegrees == 180) p = Pt(1.0 - p.x, 1.0 - p.y)
            onFrame(image.imageInfo.timestamp / 1_000_000L, p)
        } finally {
            image.close()
        }
    }
}
