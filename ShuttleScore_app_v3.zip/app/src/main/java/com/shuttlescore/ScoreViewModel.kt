package com.shuttlescore

import android.os.SystemClock
import androidx.lifecycle.ViewModel
import com.shuttlescore.core.GameState
import com.shuttlescore.core.ScoreEngine
import com.shuttlescore.core.Side
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** One line of the score timeline, used later to burn the score into the video. */
data class ScoreEvent(val tMs: Long, val state: GameState)

class ScoreViewModel : ViewModel() {
    private val engine = ScoreEngine()
    private val _state = MutableStateFlow(engine.state)
    val state: StateFlow<GameState> = _state.asStateFlow()

    private var recordingStartMs: Long? = null
    private val events = mutableListOf<ScoreEvent>()

    fun point(side: Side) {
        engine.pointTo(side)
        publish()
    }

    fun setFirstServer(side: Side) {
        engine.setFirstServer(side)
        publish()
    }

    fun undo() {
        engine.undo()
        publish()
    }

    fun newMatch() {
        engine.reset()
        events.clear()
        publish()
    }

    fun onRecordingStarted() {
        recordingStartMs = SystemClock.elapsedRealtime()
        events.clear()
        // Initial state at t=0 so the overlay shows the score from the first frame.
        events.add(ScoreEvent(0, engine.state))
    }

    fun onRecordingStopped() {
        recordingStartMs = null
    }

    fun timeline(): List<ScoreEvent> = events.toList()

    /** CSV: t_ms,scoreA,scoreB,gamesA,gamesB,server */
    fun eventsCsv(): String = buildString {
        appendLine("t_ms,scoreA,scoreB,gamesA,gamesB,server")
        events.forEach { e ->
            val s = e.state
            appendLine("${e.tMs},${s.scoreA},${s.scoreB},${s.gamesA},${s.gamesB},${s.server.name}")
        }
    }

    private fun publish() {
        _state.value = engine.state
        val start = recordingStartMs ?: return
        events.add(ScoreEvent(SystemClock.elapsedRealtime() - start, engine.state))
    }
}

fun GameState.encode(): String = "$scoreA,$scoreB,$gamesA,$gamesB,${server.name}"

fun decodeGameState(text: String): GameState? = runCatching {
    val p = text.split(",")
    GameState(
        scoreA = p[0].toInt(),
        scoreB = p[1].toInt(),
        gamesA = p[2].toInt(),
        gamesB = p[3].toInt(),
        server = Side.valueOf(p[4])
    )
}.getOrNull()
