package com.shuttlescore

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import com.google.common.collect.ImmutableList
import com.shuttlescore.core.GameState
import com.shuttlescore.core.Side
import java.io.File

/** Draws the scoreboard in the top-left of the video, changing as the score timeline changes. */
@OptIn(UnstableApi::class)
private class ScoreOverlay(
    private val timeline: List<ScoreEvent>,
    private val widthPx: Int
) : BitmapOverlay() {
    private val heightPx = (widthPx * 0.34f).toInt()
    private val cache = HashMap<Int, Bitmap>()
    private val settings = OverlaySettings.Builder()
        .setOverlayFrameAnchor(-1f, 1f)
        .setBackgroundFrameAnchor(-0.96f, 0.94f)
        .build()

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings = settings

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val tMs = presentationTimeUs / 1000
        var idx = 0
        for (i in timeline.indices) if (timeline[i].tMs <= tMs) idx = i else break
        return cache.getOrPut(idx) { render(timeline.getOrNull(idx)?.state ?: GameState()) }
    }

    private fun render(s: GameState): Bitmap {
        val bmp = Bitmap.createBitmap(widthPx, heightPx, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(200, 0, 0, 0) }
        c.drawRoundRect(RectF(0f, 0f, widthPx.toFloat(), heightPx.toFloat()), heightPx * 0.18f, heightPx * 0.18f, bg)

        val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = Paint.Align.CENTER; textSize = heightPx * 0.2f; color = Color.LTGRAY
        }
        val big = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = Paint.Align.CENTER; textSize = heightPx * 0.5f; color = Color.WHITE
            typeface = Typeface.DEFAULT_BOLD
        }
        fun column(cx: Float, name: String, score: Int, games: Int, serving: Boolean) {
            label.color = if (serving) Color.rgb(255, 213, 79) else Color.LTGRAY
            c.drawText(if (serving) "$name ●" else name, cx, heightPx * 0.25f, label)
            c.drawText("$score", cx, heightPx * 0.7f, big)
            label.color = Color.LTGRAY
            c.drawText("Games $games", cx, heightPx * 0.92f, label)
        }
        column(widthPx * 0.2f, "A", s.scoreA, s.gamesA, s.server == Side.A)
        c.drawText("-", widthPx * 0.5f, heightPx * 0.7f, big)
        column(widthPx * 0.8f, "B", s.scoreB, s.gamesB, s.server == Side.B)
        return bmp
    }
}

object OverlayExporter {
    /**
     * Re-encodes the recording with the score burned in, then saves it to Movies/ShuttleScore.
     * Runs offline on the phone. [onResult] is called on the main thread.
     */
    @OptIn(UnstableApi::class)
    fun export(ctx: Context, input: Uri, timeline: List<ScoreEvent>, onResult: (String) -> Unit) {
        val app = ctx.applicationContext
        val main = Handler(Looper.getMainLooper())
        main.post {
            try {
                val overlayWidth = (videoWidthOf(app, input) * 0.28f).toInt().coerceAtLeast(240)
                val overlay = ScoreOverlay(timeline, overlayWidth)
                val effects = Effects(emptyList(), listOf(OverlayEffect(ImmutableList.of<TextureOverlay>(overlay))))
                val item = EditedMediaItem.Builder(MediaItem.fromUri(input)).setEffects(effects).build()
                val outFile = File(app.cacheDir, "score_${System.currentTimeMillis()}.mp4")

                val transformer = Transformer.Builder(app)
                    .addListener(object : Transformer.Listener {
                        override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                            Thread {
                                val message = runCatching { saveToMovies(app, outFile) }
                                    .fold({ "Saved with score: Movies/ShuttleScore" }, { "Save failed: ${it.message}" })
                                main.post { onResult(message) }
                            }.start()
                        }

                        override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                            main.post { onResult("Export failed: ${exportException.errorCodeName}") }
                        }
                    })
                    .build()
                transformer.start(item, outFile.absolutePath)
            } catch (e: Exception) {
                onResult("Export failed: ${e.message}")
            }
        }
    }

    private fun videoWidthOf(ctx: Context, uri: Uri): Int {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 1920
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 1080
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) h else w
        } catch (e: Exception) {
            1920
        } finally {
            r.release()
        }
    }

    private fun saveToMovies(ctx: Context, file: File) {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, file.nameWithoutExtension + "_scored")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ShuttleScore")
        }
        val uri = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: error("could not create file")
        ctx.contentResolver.openOutputStream(uri)!!.use { out -> file.inputStream().use { it.copyTo(out) } }
        file.delete()
    }
}
