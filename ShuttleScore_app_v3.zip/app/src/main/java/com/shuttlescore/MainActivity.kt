package com.shuttlescore

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.shuttlescore.core.GameState
import com.shuttlescore.core.Side

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(modifier = Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

private enum class Screen { HOME, SCORER, VIEWER }

private fun requiredPermissions(): List<String> {
    val list = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
    if (Build.VERSION.SDK_INT >= 31) {
        list += Manifest.permission.BLUETOOTH_SCAN
        list += Manifest.permission.BLUETOOTH_ADVERTISE
        list += Manifest.permission.BLUETOOTH_CONNECT
    } else {
        list += Manifest.permission.ACCESS_FINE_LOCATION
    }
    if (Build.VERSION.SDK_INT >= 33) list += Manifest.permission.NEARBY_WIFI_DEVICES
    return list
}

@Composable
private fun App(vm: ScoreViewModel = viewModel()) {
    val ctx = LocalContext.current
    val perms = remember { requiredPermissions() }
    var granted by remember {
        mutableStateOf(perms.all { ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED })
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        granted = perms.all { result[it] == true || ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED }
    }
    LaunchedEffect(Unit) { if (!granted) launcher.launch(perms.toTypedArray()) }

    var screen by remember { mutableStateOf(Screen.HOME) }
    when (screen) {
        Screen.HOME -> HomeScreen(
            granted = granted,
            onAskPermissions = { launcher.launch(perms.toTypedArray()) },
            onScorer = { screen = Screen.SCORER },
            onViewer = { screen = Screen.VIEWER }
        )
        Screen.SCORER -> ScorerScreen(vm, onBack = { screen = Screen.HOME })
        Screen.VIEWER -> ViewerScreen(onBack = { screen = Screen.HOME })
    }
}

@Composable
private fun HomeScreen(granted: Boolean, onAskPermissions: () -> Unit, onScorer: () -> Unit, onViewer: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("ShuttleScore", fontSize = 34.sp, fontWeight = FontWeight.Bold)
        Text("Badminton score, recording and mirror", modifier = Modifier.padding(bottom = 32.dp))
        if (!granted) {
            Text("Camera, microphone and nearby-device permissions are needed.", textAlign = TextAlign.Center)
            Button(onClick = onAskPermissions, modifier = Modifier.padding(vertical = 12.dp)) { Text("Allow permissions") }
        }
        Button(onClick = onScorer, enabled = granted, modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
            Text("Scorer phone (camera + score)")
        }
        OutlinedButton(onClick = onViewer, enabled = granted, modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
            Text("Viewer phone (mirror score)")
        }
    }
}

@Composable
internal fun ScoreBoard(state: GameState, modifier: Modifier = Modifier, big: Boolean = false) {
    val numSize = if (big) 96.sp else 40.sp
    Row(
        modifier = modifier
            .background(Color(0xCC000000), RoundedCornerShape(16.dp))
            .padding(horizontal = 20.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(if (big) 40.dp else 20.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        SideColumn("A", state.scoreA, state.gamesA, state.server == Side.A, numSize)
        Text("-", fontSize = numSize, color = Color.White)
        SideColumn("B", state.scoreB, state.gamesB, state.server == Side.B, numSize)
    }
}

@Composable
private fun SideColumn(name: String, score: Int, games: Int, serving: Boolean, numSize: androidx.compose.ui.unit.TextUnit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(if (serving) "$name  ●" else name, color = if (serving) Color(0xFFFFD54F) else Color.LightGray)
        Text("$score", fontSize = numSize, fontWeight = FontWeight.Bold, color = Color.White)
        Text("Games $games", color = Color.LightGray)
    }
}

@Composable
private fun ViewerScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var state by remember { mutableStateOf(GameState()) }
    var status by remember { mutableStateOf("Starting") }
    DisposableEffect(Unit) {
        val mirror = MirrorManager(ctx, currentState = { state }, onState = { state = it }, onStatus = { status = it })
        mirror.startViewer()
        onDispose { mirror.stop() }
    }
    Column(
        modifier = Modifier.fillMaxSize().background(Color.Black).padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        ScoreBoard(state, big = true)
        Text(status, color = Color.LightGray, modifier = Modifier.padding(top = 16.dp))
        OutlinedButton(onClick = onBack, modifier = Modifier.padding(top = 24.dp)) { Text("Back") }
    }
}
