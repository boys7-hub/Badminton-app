package com.shuttlescore.core

import kotlin.math.abs
import kotlin.math.hypot

/**
 * Classical (no neural network) detector for a small white, fast-moving shuttlecock.
 *
 * Works on the luma (brightness) plane of consecutive frames: a shuttle shows up as a small
 * bright blob that became bright since the previous frame. Large blobs (players, clothing,
 * lights) and frames where most of the image changed (camera shake) are rejected.
 *
 * This is a first, tunable detector. A trained model (TrackNet-style) is the upgrade path.
 */
class ShuttleDetector(
    private val brightThreshold: Int = 185,
    private val motionThreshold: Int = 30,
    private val minArea: Int = 2,
    private val maxArea: Int = 90,
    private val maxBlobSize: Int = 16,
    private val maxMaskPixels: Int = 25_000
) {
    private var prev: ByteArray? = null
    private var mask = BooleanArray(0)
    private val cand = IntArray(maxMaskPixels)
    private val stack = IntArray(maxMaskPixels)

    fun reset() {
        prev = null
    }

    /**
     * @param cur compact luma plane, width*height bytes
     * @param predicted last known shuttle position (normalised 0..1) to prefer nearby blobs
     * @return shuttle centre in normalised image coordinates (0..1), or null if none found
     */
    fun detect(cur: ByteArray, w: Int, h: Int, predicted: Pt? = null, maxJump: Double = 0.2): Pt? {
        val p = prev
        if (p == null || p.size != cur.size) {
            prev = cur.copyOf()
            return null
        }
        if (mask.size != cur.size) mask = BooleanArray(cur.size)

        var n = 0
        var overflow = false
        for (i in cur.indices) {
            val c = cur[i].toInt() and 0xFF
            if (c >= brightThreshold && c - (p[i].toInt() and 0xFF) >= motionThreshold) {
                if (n >= maxMaskPixels) {
                    overflow = true
                    break
                }
                cand[n++] = i
                mask[i] = true
            }
        }
        if (overflow) {
            java.util.Arrays.fill(mask, false)
            System.arraycopy(cur, 0, p, 0, cur.size)
            return null
        }

        var best: Pt? = null
        var bestScore = -1e18
        for (k in 0 until n) {
            val start = cand[k]
            if (!mask[start]) continue
            var sp = 0
            stack[sp++] = start
            mask[start] = false
            var area = 0
            var sx = 0L
            var sy = 0L
            var sl = 0L
            var minX = Int.MAX_VALUE
            var maxX = -1
            var minY = Int.MAX_VALUE
            var maxY = -1
            while (sp > 0) {
                val i = stack[--sp]
                val x = i % w
                val y = i / w
                area++
                sx += x
                sy += y
                sl += cur[i].toInt() and 0xFF
                if (x < minX) minX = x
                if (x > maxX) maxX = x
                if (y < minY) minY = y
                if (y > maxY) maxY = y
                if (x > 0 && mask[i - 1]) { mask[i - 1] = false; stack[sp++] = i - 1 }
                if (x < w - 1 && mask[i + 1]) { mask[i + 1] = false; stack[sp++] = i + 1 }
                if (y > 0 && mask[i - w]) { mask[i - w] = false; stack[sp++] = i - w }
                if (y < h - 1 && mask[i + w]) { mask[i + w] = false; stack[sp++] = i + w }
            }
            if (area < minArea || area > maxArea) continue
            if (maxX - minX + 1 > maxBlobSize || maxY - minY + 1 > maxBlobSize) continue

            val centre = Pt((sx.toDouble() / area + 0.5) / w, (sy.toDouble() / area + 0.5) / h)
            val meanLuma = sl.toDouble() / area
            val score = if (predicted != null) {
                val d = hypot(centre.x - predicted.x, centre.y - predicted.y)
                if (d > maxJump) continue
                -d * 100.0 + meanLuma / 10.0
            } else {
                meanLuma - abs(area - 10)
            }
            if (score > bestScore) {
                bestScore = score
                best = centre
            }
        }

        System.arraycopy(cur, 0, p, 0, cur.size)
        return best
    }
}
