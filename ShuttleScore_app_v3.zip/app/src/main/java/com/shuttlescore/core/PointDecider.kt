package com.shuttlescore.core

/** What the vision pipeline reports when it thinks a rally has ended. */
data class RallyEnd(
    val landing: Pt?,            // shuttle landing in court metres, null if never seen landing
    val lastHitter: Side?,       // side that last hit the shuttle, null if unknown
    val lastCrossedNetToward: Side?, // side the shuttle was heading toward when it last crossed the net
    val singles: Boolean,
    val detectionConfidence: Double // 0..1 from the shuttle tracker
)

sealed class PointDecision {
    /** Confident enough to award automatically (still undoable for a few seconds). */
    data class Auto(val winner: Side, val reason: String) : PointDecision()

    /** Suggested winner, but the user must confirm with one tap. */
    data class NeedsConfirm(val suggested: Side?, val reason: String) : PointDecision()
}

class PointDecider(
    private val calibration: CourtCalibration,
    private val autoConfidence: Double = 0.75
) {
    fun decide(end: RallyEnd): PointDecision {
        val landing = end.landing
        if (landing == null || end.detectionConfidence < 0.3) {
            return PointDecision.NeedsConfirm(null, "Shuttle landing not detected")
        }

        val landedSide = Court.sideOf(landing)
        val margin = calibration.marginToLine(landing, end.singles)
        val err = calibration.landingErrorMetres(landing)
        val inside = margin >= 0

        // Too close to a line for a phone camera to judge: ask the user.
        if (kotlin.math.abs(margin) < err) {
            return PointDecision.NeedsConfirm(
                suggested = winnerFor(inside, landedSide, end.lastHitter),
                reason = "Landing within ${"%.0f".format(err * 100)} cm of a line"
            )
        }

        // Shuttle crossed the net toward a side but landed on the hitter's own side:
        // net touch / bad tracking. Do not trust automatically.
        if (end.lastCrossedNetToward != null && inside && end.lastCrossedNetToward != landedSide) {
            return PointDecision.NeedsConfirm(
                suggested = winnerFor(inside, landedSide, end.lastHitter),
                reason = "Shuttle path and landing side disagree"
            )
        }

        val winner = winnerFor(inside, landedSide, end.lastHitter)
        if (winner == null) {
            return PointDecision.NeedsConfirm(null, "Out ball but last hitter unknown")
        }
        val conf = end.detectionConfidence * (if (inside) 1.0 else 0.9)
        val reason = if (inside) "In on side $landedSide" else "Out, last hit by ${end.lastHitter}"
        return if (conf >= autoConfidence) PointDecision.Auto(winner, reason)
        else PointDecision.NeedsConfirm(winner, "Low confidence: $reason")
    }

    private fun winnerFor(inside: Boolean, landedSide: Side, lastHitter: Side?): Side? =
        if (inside) opposite(landedSide)
        else lastHitter?.let { opposite(it) }

    private fun opposite(s: Side) = if (s == Side.A) Side.B else Side.A
}
