package com.shuttlescore.core

enum class Side { A, B }

data class GameState(
    val scoreA: Int = 0,
    val scoreB: Int = 0,
    val server: Side = Side.A,
    val gamesA: Int = 0,
    val gamesB: Int = 0,
    val matchWinner: Side? = null
) {
    val gameNumber: Int get() = gamesA + gamesB + 1
}

/**
 * Badminton scoring (BWF): rally point, game to 21, win by 2, cap at 30.
 * Best of 3 games. The side that wins a rally serves next.
 * Undo is supported through a history stack.
 */
class ScoreEngine(
    private val pointsToWin: Int = 21,
    private val cap: Int = 30,
    private val gamesToWin: Int = 2
) {
    private val history = ArrayDeque<GameState>()
    var state = GameState()
        private set

    fun pointTo(winner: Side): GameState {
        if (state.matchWinner != null) return state
        history.addLast(state)

        var a = state.scoreA + if (winner == Side.A) 1 else 0
        var b = state.scoreB + if (winner == Side.B) 1 else 0
        var gA = state.gamesA
        var gB = state.gamesB
        var server = winner
        var matchWinner: Side? = null

        val gameWinner = gameWinnerOrNull(a, b)
        if (gameWinner != null) {
            if (gameWinner == Side.A) gA++ else gB++
            if (gA == gamesToWin) matchWinner = Side.A
            if (gB == gamesToWin) matchWinner = Side.B
            if (matchWinner == null) {
                // next game: winner of previous game serves first
                a = 0
                b = 0
                server = gameWinner
            }
        }
        state = GameState(a, b, server, gA, gB, matchWinner)
        return state
    }

    /** Choose who serves first. Only allowed at 0-0 before the first rally of a game. */
    fun setFirstServer(side: Side) {
        if (state.scoreA == 0 && state.scoreB == 0 && state.matchWinner == null) {
            state = state.copy(server = side)
        }
    }

    fun undo(): GameState {
        if (history.isNotEmpty()) state = history.removeLast()
        return state
    }

    fun reset() {
        history.clear()
        state = GameState()
    }

    private fun gameWinnerOrNull(a: Int, b: Int): Side? {
        if (a == cap) return Side.A
        if (b == cap) return Side.B
        if (a >= pointsToWin && a - b >= 2) return Side.A
        if (b >= pointsToWin && b - a >= 2) return Side.B
        return null
    }

    /** Doubles/singles rule: server stands in right court when their score is even. */
    fun serverCourtIsRight(): Boolean {
        val s = if (state.server == Side.A) state.scoreA else state.scoreB
        return s % 2 == 0
    }
}
