package com.shuttlescore.core

enum class CameraMode { BEHIND_COURT, SIDE_VIEW }

data class Pt(val x: Double, val y: Double)

/**
 * Court coordinates in metres. Origin = corner of side A's back-left line.
 * x: 0..6.10 across the court (doubles width), y: 0..13.40 along the court.
 * The net is at y = 6.70. Side A is y < 6.70, side B is y >= 6.70.
 */
object Court {
    const val WIDTH = 6.10
    const val LENGTH = 13.40
    const val NET_Y = 6.70
    const val SINGLES_INSET = 0.46
    const val SERVICE_BACK_INSET_DOUBLES = 0.76

    val corners = listOf(Pt(0.0, 0.0), Pt(WIDTH, 0.0), Pt(WIDTH, LENGTH), Pt(0.0, LENGTH))

    fun sideOf(p: Pt): Side = if (p.y < NET_Y) Side.A else Side.B
}

/**
 * Maps phone-camera pixels to court metres using a homography built from the four
 * court corners the user taps (order: A-left, A-right, B-right, B-left as seen on court).
 * Works for both behind-the-court and side-view placement; the maths is identical,
 * only the accuracy near the camera differs (see [cameraMode]).
 */
class CourtCalibration(
    imageCorners: List<Pt>,
    val cameraMode: CameraMode
) {
    private val h: DoubleArray // 3x3 homography image -> court, row-major, h[8] = 1

    init {
        require(imageCorners.size == 4) { "Need exactly 4 court corners" }
        h = solveHomography(imageCorners, Court.corners)
    }

    fun imageToCourt(p: Pt): Pt {
        val w = h[6] * p.x + h[7] * p.y + h[8]
        return Pt(
            (h[0] * p.x + h[1] * p.y + h[2]) / w,
            (h[3] * p.x + h[4] * p.y + h[5]) / w
        )
    }

    /** Distance in metres from the point to the nearest boundary line (negative = outside). */
    fun marginToLine(c: Pt, singles: Boolean): Double {
        val inset = if (singles) Court.SINGLES_INSET else 0.0
        val dx = minOf(c.x - inset, Court.WIDTH - inset - c.x)
        val dy = minOf(c.y, Court.LENGTH - c.y)
        return minOf(dx, dy)
    }

    /**
     * Expected landing error in metres. Behind-court views see the far half well but the
     * lateral lines poorly; side views see sidelines well but depth (back line) poorly.
     * Used to decide when a call is too close to trust.
     */
    fun landingErrorMetres(c: Pt): Double {
        val base = 0.15
        return when (cameraMode) {
            CameraMode.BEHIND_COURT -> base + 0.04 * c.y.coerceAtLeast(0.0) / 3.0
            CameraMode.SIDE_VIEW -> base + 0.06 * kotlin.math.abs(c.x - Court.WIDTH / 2) / 3.0 + 0.10
        }
    }

    private fun solveHomography(src: List<Pt>, dst: List<Pt>): DoubleArray {
        val a = Array(8) { DoubleArray(9) }
        for (i in 0 until 4) {
            val (x, y) = src[i]
            val (u, v) = dst[i]
            a[2 * i] = doubleArrayOf(x, y, 1.0, 0.0, 0.0, 0.0, -u * x, -u * y, u)
            a[2 * i + 1] = doubleArrayOf(0.0, 0.0, 0.0, x, y, 1.0, -v * x, -v * y, v)
        }
        for (col in 0 until 8) {
            var pivot = col
            for (r in col + 1 until 8) if (kotlin.math.abs(a[r][col]) > kotlin.math.abs(a[pivot][col])) pivot = r
            require(kotlin.math.abs(a[pivot][col]) > 1e-12) { "Corners are degenerate" }
            val tmp = a[col]; a[col] = a[pivot]; a[pivot] = tmp
            for (r in 0 until 8) {
                if (r == col) continue
                val f = a[r][col] / a[col][col]
                for (c in col until 9) a[r][c] -= f * a[col][c]
            }
        }
        val out = DoubleArray(9)
        for (i in 0 until 8) out[i] = a[i][8] / a[i][i]
        out[8] = 1.0
        return out
    }
}
