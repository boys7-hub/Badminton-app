package com.shuttlescore.core

import kotlin.math.hypot
import kotlin.math.max

/**
 * Turns a stream of per-frame shuttle detections (normalised image coordinates, or null)
 * into a "rally ended" event once the shuttle has been gone long enough.
 *
 * Landing point = last position the shuttle was seen. Last hitter = inferred from which way
 * the shuttle was travelling along the court length at the end of its flight.
 * Confidence = share of frames in the rally where the shuttle was found.
 */
class RallyTracker(
    private val endGapMs: Long = 900,
    private val minDetections: Int = 8,
    private val maxJumpNorm: Double = 0.2,
    private val fullConfidenceRatio: Double = 0.7
) {
    private var calibration: CourtCalibration? = null
    private var singles = false
    private val samples = ArrayList<Pair<Long, Pt>>()
    private var framesInTrack = 0
    private var framesAtLastSample = 0

    @Synchronized
    fun configure(calibration: CourtCalibration?, singles: Boolean) {
        this.calibration = calibration
        this.singles = singles
        reset()
    }

    @Synchronized
    fun reset() {
        samples.clear()
        framesInTrack = 0
        framesAtLastSample = 0
    }

    @Synchronized
    fun predicted(): Pt? = samples.lastOrNull()?.second

    @Synchronized
    fun recent(n: Int): List<Pt> = samples.takeLast(n).map { it.second }

    @Synchronized
    fun onFrame(tMs: Long, shuttle: Pt?): RallyEnd? {
        val last = samples.lastOrNull()
        if (last != null) framesInTrack++

        if (shuttle != null) {
            if (last != null) {
                val gap = tMs - last.first
                if (gap > endGapMs) {
                    val end = finish()
                    addSample(tMs, shuttle)
                    return end
                }
                val jump = hypot(shuttle.x - last.second.x, shuttle.y - last.second.y)
                if (jump > maxJumpNorm * max(1.0, gap / 33.0)) return null // outlier, ignore
            }
            addSample(tMs, shuttle)
            return null
        }

        if (last != null && tMs - last.first > endGapMs) return finish()
        return null
    }

    private fun addSample(tMs: Long, p: Pt) {
        if (samples.isEmpty()) framesInTrack = 1
        samples.add(tMs to p)
        framesAtLastSample = framesInTrack
    }

    private fun finish(): RallyEnd? {
        val cal = calibration
        val snapshot = ArrayList(samples)
        val n = snapshot.size
        val ratio = if (framesAtLastSample > 0) n.toDouble() / framesAtLastSample else 0.0
        reset()
        if (cal == null || n < minDetections) return null

        val landing = cal.imageToCourt(snapshot.last().second)
        val ys = snapshot.map { cal.imageToCourt(it.second).y }
        val k = minOf(3, n / 2)
        val dy = ys.takeLast(k).average() - ys.dropLast(k).takeLast(k).average()
        val headedTo = when {
            dy > 0.3 -> Side.B
            dy < -0.3 -> Side.A
            else -> null
        }
        val lastHitter = headedTo?.let { if (it == Side.A) Side.B else Side.A }
        return RallyEnd(
            landing = landing,
            lastHitter = lastHitter,
            lastCrossedNetToward = headedTo,
            singles = singles,
            detectionConfidence = (ratio / fullConfidenceRatio).coerceIn(0.0, 1.0)
        )
    }
}
