package com.shuttlescore

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Size
import android.view.Surface
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.shuttlescore.core.CameraMode
import com.shuttlescore.core.CourtCalibration
import com.shuttlescore.core.PointDecider
import com.shuttlescore.core.PointDecision
import com.shuttlescore.core.Pt
import com.shuttlescore.core.RallyTracker
import com.shuttlescore.core.Side
import java.util.concurrent.Executors

private val CALIBRATION_STEPS = listOf(
    "Tap side A back corner 1",
    "Tap side A back corner 2 (same back line)",
    "Tap side B corner on the same sideline as corner 2",
    "Tap side B corner on the same sideline as corner 1"
)

@Composable
internal fun ScorerScreen(vm: ScoreViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val state by vm.state.collectAsStateWithLifecycle()

    var status by remember { mutableStateOf("Starting mirror") }
    var recording by remember { mutableStateOf<Recording?>(null) }
    var note by remember { mutableStateOf("") }
    var lastVideo by remember { mutableStateOf<Uri?>(null) }
    var exporting by remember { mutableStateOf(false) }

    var cameraMode by remember { mutableStateOf(CameraMode.BEHIND_COURT) }
    var singles by remember { mutableStateOf(false) }
    var calibrating by remember { mutableStateOf(false) }
    var taps by remember { mutableStateOf(listOf<Pt>()) }
    var calibration by remember { mutableStateOf<CourtCalibration?>(null) }
    var aiOn by remember { mutableStateOf(false) }
    var trail by remember { mutableStateOf(listOf<Pt>()) }
    var pending by remember { mutableStateOf<PointDecision.NeedsConfirm?>(null) }

    val mainHandler = remember { Handler(Looper.getMainLooper()) }
    val tracker = remember { RallyTracker() }
    LaunchedEffect(calibration, singles, aiOn) {
        tracker.configure(if (aiOn) calibration else null, singles)
        if (!aiOn) trail = emptyList()
    }

    fun handleDecision(d: PointDecision) {
        when (d) {
            is PointDecision.Auto -> {
                vm.point(d.winner)
                pending = null
                note = "AI: ${d.winner} wins (${d.reason}). Tap Undo if wrong."
            }
            is PointDecision.NeedsConfirm -> pending = d
        }
    }

    // --- Mirror ---
    val mirror = remember {
        MirrorManager(ctx, currentState = { vm.state.value }, onState = {}, onStatus = { status = it })
    }
    DisposableEffect(Unit) {
        mirror.startScorer()
        onDispose { mirror.stop() }
    }
    LaunchedEffect(state) { mirror.send(state) }

    // --- Camera use cases ---
    val ratio169 = remember {
        ResolutionSelector.Builder()
            .setAspectRatioStrategy(AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY)
            .build()
    }
    val previewUseCase = remember { Preview.Builder().setResolutionSelector(ratio169).build() }
    val videoCapture = remember {
        val recorder = Recorder.Builder()
            .setQualitySelector(
                QualitySelector.from(Quality.FHD, FallbackStrategy.lowerQualityOrHigherThan(Quality.HD))
            )
            .build()
        VideoCapture.withOutput(recorder)
    }
    val analysisExecutor = remember { Executors.newSingleThreadExecutor() }
    DisposableEffect(Unit) { onDispose { analysisExecutor.shutdown() } }
    val analysis = remember {
        val selector = ResolutionSelector.Builder()
            .setAspectRatioStrategy(AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY)
            .setResolutionStrategy(
                ResolutionStrategy(Size(1280, 720), ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER)
            )
            .build()
        ImageAnalysis.Builder()
            .setResolutionSelector(selector)
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .build()
            .also { ia ->
                ia.setAnalyzer(
                    analysisExecutor,
                    ShuttleAnalyzer(
                        enabled = { aiOn && calibration != null },
                        predictor = { tracker.predicted() }
                    ) { tMs, p ->
                        val cal = calibration
                        if (aiOn && cal != null) {
                            val end = tracker.onFrame(tMs, p)
                            val recent = tracker.recent(40)
                            val decision = end?.let { PointDecider(cal).decide(it) }
                            mainHandler.post {
                                trail = recent
                                if (decision != null) handleDecision(decision)
                            }
                        }
                    }
                )
            }
    }

    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        // Camera preview and drawing layer share one 16:9 box so tapped points match image coordinates.
        Box(modifier = Modifier.align(Alignment.Center).aspectRatio(16f / 9f)) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { c ->
                    PreviewView(c).also { pv ->
                        pv.scaleType = PreviewView.ScaleType.FIT_CENTER
                        previewUseCase.setSurfaceProvider(pv.surfaceProvider)
                        val future = ProcessCameraProvider.getInstance(c)
                        future.addListener({
                            val provider = future.get()
                            provider.unbindAll()
                            try {
                                provider.bindToLifecycle(
                                    lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA,
                                    previewUseCase, videoCapture, analysis
                                )
                            } catch (e: Exception) {
                                // This phone cannot run preview + recording + analysis together.
                                try {
                                    provider.unbindAll()
                                    provider.bindToLifecycle(
                                        lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA,
                                        previewUseCase, videoCapture
                                    )
                                    note = "AI analysis unavailable on this camera setup"
                                } catch (e2: Exception) {
                                    note = "Camera error: ${e2.message}"
                                }
                            }
                        }, ContextCompat.getMainExecutor(c))
                    }
                },
                update = { v ->
                    // Keep all use cases in the screen's current rotation (landscape can flip 180 degrees).
                    val rot = v.display?.rotation ?: Surface.ROTATION_90
                    previewUseCase.targetRotation = rot
                    analysis.targetRotation = rot
                    videoCapture.targetRotation = rot
                }
            )
            Canvas(
                modifier = Modifier.fillMaxSize().pointerInput(calibrating) {
                    if (calibrating) {
                        detectTapGestures { off ->
                            val p = Pt(off.x / size.width.toDouble(), off.y / size.height.toDouble())
                            val next = taps + p
                            taps = next
                            if (next.size == 4) {
                                calibration = runCatching { CourtCalibration(next, cameraMode) }.getOrNull()
                                calibrating = false
                                note = if (calibration != null) "Calibrated. Turn AI on." else "Calibration failed, try again"
                            }
                        }
                    }
                }
            ) {
                fun px(p: Pt) = Offset((p.x * size.width).toFloat(), (p.y * size.height).toFloat())
                taps.forEach { drawCircle(Color.Red, radius = 10f, center = px(it)) }
                if (taps.size == 4) {
                    for (i in 0 until 4) drawLine(Color.Green, px(taps[i]), px(taps[(i + 1) % 4]), strokeWidth = 4f)
                }
                for (i in 1 until trail.size) {
                    drawLine(Color.Yellow, px(trail[i - 1]), px(trail[i]), strokeWidth = 5f)
                }
                trail.lastOrNull()?.let { drawCircle(Color.Yellow, radius = 9f, center = px(it)) }
            }
        }

        // Score and status, top centre.
        Column(modifier = Modifier.align(Alignment.TopCenter).padding(top = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            ScoreBoard(state)
            state.matchWinner?.let {
                Text("Match won by side $it", color = Color(0xFFFFD54F), fontSize = 14.sp)
            }
            Text(
                "Mirror: $status" + (if (recording != null) "   ● REC" else "") + (if (aiOn) "   AI on" else ""),
                color = Color.White,
                fontSize = 12.sp,
                modifier = Modifier.background(Color(0x99000000), RoundedCornerShape(8.dp)).padding(horizontal = 8.dp, vertical = 2.dp)
            )
            val message = if (calibrating) CALIBRATION_STEPS[taps.size.coerceAtMost(3)] else note
            if (message.isNotEmpty()) {
                Text(
                    message, color = Color.White, fontSize = 13.sp,
                    modifier = Modifier.padding(top = 4.dp).background(Color(0x99000000), RoundedCornerShape(8.dp)).padding(horizontal = 8.dp, vertical = 2.dp)
                )
            }
        }

        // AI settings, right edge.
        val small = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
        Column(modifier = Modifier.align(Alignment.CenterEnd).padding(end = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton(onClick = { cameraMode = if (cameraMode == CameraMode.BEHIND_COURT) CameraMode.SIDE_VIEW else CameraMode.BEHIND_COURT }, contentPadding = small) {
                Text(if (cameraMode == CameraMode.BEHIND_COURT) "View: Behind" else "View: Side", fontSize = 12.sp)
            }
            OutlinedButton(onClick = { singles = !singles }, contentPadding = small) {
                Text(if (singles) "Singles" else "Doubles", fontSize = 12.sp)
            }
            OutlinedButton(
                onClick = { vm.setFirstServer(if (state.server == Side.A) Side.B else Side.A) },
                enabled = state.scoreA == 0 && state.scoreB == 0,
                contentPadding = small
            ) { Text("Server: ${state.server}", fontSize = 12.sp) }
            OutlinedButton(onClick = { taps = emptyList(); calibration = null; aiOn = false; calibrating = true; note = "" }, contentPadding = small) {
                Text("Calibrate", fontSize = 12.sp)
            }
            Button(onClick = { aiOn = !aiOn; pending = null }, enabled = calibration != null, contentPadding = small) {
                Text(if (aiOn) "AI: ON" else "AI: OFF", fontSize = 12.sp)
            }
            if (lastVideo != null && recording == null && !exporting) {
                Button(
                    onClick = {
                        exporting = true
                        note = "Exporting video with score..."
                        val video = lastVideo
                        if (video == null) {
                            exporting = false
                        } else {
                            OverlayExporter.export(ctx, video, vm.timeline()) { result ->
                                note = result
                                exporting = false
                            }
                        }
                    },
                    contentPadding = small
                ) { Text("Export score video", fontSize = 12.sp) }
            }
        }

        // Controls, bottom.
        Column(
            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            pending?.let { p ->
                Row(
                    modifier = Modifier.background(Color(0xCC000000), RoundedCornerShape(12.dp)).padding(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("AI unsure: ${p.reason}", color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
                    Button(
                        onClick = { vm.point(Side.A); pending = null },
                        colors = if (p.suggested == Side.A) ButtonDefaults.buttonColors() else ButtonDefaults.filledTonalButtonColors()
                    ) { Text("A wins") }
                    Button(
                        onClick = { vm.point(Side.B); pending = null },
                        colors = if (p.suggested == Side.B) ButtonDefaults.buttonColors() else ButtonDefaults.filledTonalButtonColors()
                    ) { Text("B wins") }
                    OutlinedButton(onClick = { pending = null }) { Text("Skip") }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { vm.point(Side.A) }, modifier = Modifier.weight(1f)) { Text("+1  A", fontSize = 20.sp) }
                Button(onClick = { vm.point(Side.B) }, modifier = Modifier.weight(1f)) { Text("+1  B", fontSize = 20.sp) }
                OutlinedButton(onClick = { vm.undo() }, modifier = Modifier.weight(1f)) { Text("Undo") }
                Button(
                    onClick = {
                        val active = recording
                        if (active != null) {
                            active.stop()
                            recording = null
                        } else {
                            recording = startRecording(ctx, videoCapture, vm, onNote = { note = it }, onSaved = { lastVideo = it })
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = if (recording != null) Color(0xFFB71C1C) else MaterialTheme.colorScheme.primary),
                    modifier = Modifier.weight(1f)
                ) { Text(if (recording != null) "Stop" else "Record") }
                OutlinedButton(onClick = { vm.newMatch() }, modifier = Modifier.weight(1f)) { Text("New") }
                OutlinedButton(onClick = onBack, modifier = Modifier.weight(1f)) { Text("Back") }
            }
        }
    }

    val recordingNow by rememberUpdatedState(recording)
    DisposableEffect(Unit) {
        onDispose { recordingNow?.stop() }
    }
}

private fun startRecording(
    ctx: Context,
    videoCapture: VideoCapture<Recorder>,
    vm: ScoreViewModel,
    onNote: (String) -> Unit,
    onSaved: (Uri) -> Unit
): Recording? {
    val name = "match_" + System.currentTimeMillis()
    val values = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, name)
        put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
        if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ShuttleScore")
    }
    val output = MediaStoreOutputOptions.Builder(ctx.contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
        .setContentValues(values)
        .build()
    return try {
        videoCapture.output.prepareRecording(ctx, output)
            .withAudioEnabled()
            .start(ContextCompat.getMainExecutor(ctx)) { event ->
                when (event) {
                    is VideoRecordEvent.Start -> {
                        vm.onRecordingStarted()
                        onNote("Recording to Movies/ShuttleScore")
                    }
                    is VideoRecordEvent.Finalize -> {
                        vm.onRecordingStopped()
                        if (event.hasError()) {
                            onNote("Recording error ${event.error}")
                        } else {
                            runCatching {
                                java.io.File(ctx.getExternalFilesDir(null), "$name.csv").writeText(vm.eventsCsv())
                            }
                            onSaved(event.outputResults.outputUri)
                            onNote("Saved. Tap Export score video to burn the score in.")
                        }
                    }
                    else -> Unit
                }
            }
    } catch (e: SecurityException) {
        onNote("Permission missing for recording")
        null
    }
}
