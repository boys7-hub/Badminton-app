import com.shuttlescore.core.*

object VisionCheck {
    private fun check(name: String, ok: Boolean) {
        println((if (ok) "PASS " else "FAIL ") + name)
        if (!ok) kotlin.system.exitProcess(1)
    }

    private fun frame(w: Int, h: Int, base: Int = 30, draw: (ByteArray) -> Unit = {}): ByteArray {
        val f = ByteArray(w * h) { base.toByte() }
        draw(f)
        return f
    }

    private fun square(f: ByteArray, w: Int, x0: Int, y0: Int, size: Int) {
        for (y in y0 until y0 + size) for (x in x0 until x0 + size) f[y * w + x] = 255.toByte()
    }

    @JvmStatic
    fun main(args: Array<String>) {
        val w = 320
        val h = 240

        // --- Detector ---
        val d = ShuttleDetector()
        check("first frame returns null", d.detect(frame(w, h), w, h) == null)
        val hit = d.detect(frame(w, h) { square(it, w, 100, 100, 3) }, w, h)
        check("small white dot found", hit != null &&
                Math.abs(hit.x - 101.5 / w) < 0.01 && Math.abs(hit.y - 101.5 / h) < 0.01)
        val big = d.detect(frame(w, h) { square(it, w, 50, 50, 40) }, w, h)
        check("large white blob (player) rejected", big == null)
        val still = d.detect(frame(w, h) { square(it, w, 50, 50, 40) }, w, h)
        check("static bright area ignored", still == null)

        // --- Detector picks blob nearest the prediction ---
        val d2 = ShuttleDetector()
        d2.detect(frame(w, h), w, h)
        val two = d2.detect(
            frame(w, h) { square(it, w, 20, 20, 3); square(it, w, 200, 150, 3) },
            w, h, predicted = Pt(201.5 / w, 151.5 / h)
        )
        check("prefers blob near prediction", two != null && two.x > 0.5)

        // --- Tracker with an axis-aligned calibration: court = (x*6.1, y*13.4) ---
        val cal = CourtCalibration(
            listOf(Pt(0.0, 0.0), Pt(1.0, 0.0), Pt(1.0, 1.0), Pt(0.0, 1.0)), CameraMode.BEHIND_COURT
        )
        val decider = PointDecider(cal)

        // Shuttle flies from A side toward B and lands inside B -> A wins.
        val t1 = RallyTracker()
        t1.configure(cal, singles = false)
        var end: RallyEnd? = null
        var t = 0L
        for (i in 0 until 20) {
            end = t1.onFrame(t, Pt(0.5, 0.2 + 0.65 * i / 19.0)) ?: end
            t += 33
        }
        while (t < 33L * 20 + 1100) {
            end = t1.onFrame(t, null) ?: end
            t += 33
        }
        check("rally end produced", end != null)
        check("landing is in B half", end != null && end.landing!!.y > Court.NET_Y)
        check("last hitter inferred as A", end?.lastHitter == Side.A)
        check("confidence full", end != null && end.detectionConfidence > 0.99)
        val dec = decider.decide(end!!)
        check("in on B -> A wins automatically", dec is PointDecision.Auto && dec.winner == Side.A)

        // Shuttle flies toward A and goes long past A's back line -> out, last hit by B -> A wins.
        val t2 = RallyTracker()
        t2.configure(cal, singles = false)
        var end2: RallyEnd? = null
        t = 0L
        for (i in 0 until 20) {
            end2 = t2.onFrame(t, Pt(0.5, 0.6 - 0.7 * i / 19.0)) ?: end2   // ends at y = -0.1 (out)
            t += 33
        }
        while (t < 33L * 20 + 1100) {
            end2 = t2.onFrame(t, null) ?: end2
            t += 33
        }
        val dec2 = decider.decide(end2!!)
        check("out past A back line, last hit by B -> A wins", dec2 is PointDecision.Auto && dec2.winner == Side.A)

        // Noise: 3 detections then nothing -> no rally.
        val t3 = RallyTracker()
        t3.configure(cal, singles = false)
        var end3: RallyEnd? = null
        t = 0L
        for (i in 0 until 3) { end3 = t3.onFrame(t, Pt(0.5, 0.5)) ?: end3; t += 33 }
        while (t < 2000) { end3 = t3.onFrame(t, null) ?: end3; t += 33 }
        check("noise ignored", end3 == null)

        // Sparse detections (30% of frames) -> low confidence -> asks the user.
        val t4 = RallyTracker()
        t4.configure(cal, singles = false)
        var end4: RallyEnd? = null
        t = 0L
        for (i in 0 until 60) {
            val p = if (i % 3 == 0) Pt(0.5, 0.2 + 0.65 * i / 59.0) else null
            end4 = t4.onFrame(t, p) ?: end4
            t += 33
        }
        while (t < 33L * 60 + 1100) { end4 = t4.onFrame(t, null) ?: end4; t += 33 }
        val dec4 = decider.decide(end4!!)
        check("sparse detections need confirm", dec4 is PointDecision.NeedsConfirm)

        println("VISION CHECKS PASSED")
    }
}
