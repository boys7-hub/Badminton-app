import com.shuttlescore.core.*

fun check(name: String, ok: Boolean) {
    println((if (ok) "PASS " else "FAIL ") + name)
    if (!ok) kotlin.system.exitProcess(1)
}

fun main() {
    // --- Scoring ---
    val e = ScoreEngine()
    repeat(21) { e.pointTo(Side.A) }
    check("A wins game 1 at 21-0", e.state.gamesA == 1 && e.state.scoreA == 0 && e.state.server == Side.A)

    val d = ScoreEngine()
    repeat(20) { d.pointTo(Side.A); d.pointTo(Side.B) }
    check("20-20 no winner", d.state.gamesA == 0 && d.state.gamesB == 0)
    d.pointTo(Side.A)
    check("21-20 not won (win by 2)", d.state.gamesA == 0)
    d.pointTo(Side.A)
    check("22-20 won", d.state.gamesA == 1)

    val c = ScoreEngine()
    repeat(29) { c.pointTo(Side.A); c.pointTo(Side.B) }
    c.pointTo(Side.B)
    check("30-29 cap wins game", c.state.gamesB == 1)

    val m = ScoreEngine()
    repeat(2) { repeat(21) { m.pointTo(Side.B) } }
    check("match won by B after 2 games", m.state.matchWinner == Side.B)

    val u = ScoreEngine()
    u.pointTo(Side.A); u.pointTo(Side.B); u.undo()
    check("undo restores 1-0", u.state.scoreA == 1 && u.state.scoreB == 0 && u.state.server == Side.A)

    val fs = ScoreEngine()
    fs.setFirstServer(Side.B)
    check("first server can be set at 0-0", fs.state.server == Side.B)
    fs.pointTo(Side.A)
    fs.setFirstServer(Side.B)
    check("first server locked after first point", fs.state.server == Side.A)

    // --- Calibration: fake camera looking from behind, simple trapezoid ---
    val img = listOf(Pt(100.0, 900.0), Pt(1180.0, 900.0), Pt(800.0, 200.0), Pt(480.0, 200.0))
    val cal = CourtCalibration(img, CameraMode.BEHIND_COURT)
    for ((i, p) in img.withIndex()) {
        val c2 = cal.imageToCourt(p)
        val t = Court.corners[i]
        check("corner $i maps back", kotlin.math.abs(c2.x - t.x) < 1e-6 && kotlin.math.abs(c2.y - t.y) < 1e-6)
    }

    // Diagonals of any perspective view cross at the true centre of the court (net centre).
    fun cross(a: Pt, b: Pt, c2: Pt, d2: Pt): Pt {
        val x1 = a.x; val y1 = a.y; val x2 = b.x; val y2 = b.y
        val x3 = c2.x; val y3 = c2.y; val x4 = d2.x; val y4 = d2.y
        val den = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
        val px = ((x1 * y2 - y1 * x2) * (x3 - x4) - (x1 - x2) * (x3 * y4 - y3 * x4)) / den
        val py = ((x1 * y2 - y1 * x2) * (y3 - y4) - (y1 - y2) * (x3 * y4 - y3 * x4)) / den
        return Pt(px, py)
    }
    val centreImg = cross(img[0], img[2], img[1], img[3])
    val centreCourt = cal.imageToCourt(centreImg)
    check("perspective: diagonal crossing maps to court centre",
        kotlin.math.abs(centreCourt.x - 3.05) < 1e-6 && kotlin.math.abs(centreCourt.y - 6.70) < 1e-6)

    val decider = PointDecider(cal)
    // clearly in on side B -> A wins
    val r1 = decider.decide(RallyEnd(Pt(3.0, 10.0), Side.A, Side.B, false, 0.9))
    check("in on B -> A wins auto", r1 is PointDecision.Auto && r1.winner == Side.A)
    // clearly out long past back line B, last hit by A -> B wins
    val r2 = decider.decide(RallyEnd(Pt(3.0, 14.5), Side.A, Side.B, false, 0.9))
    check("out long, hit by A -> B wins auto", r2 is PointDecision.Auto && r2.winner == Side.B)
    // right on the line -> needs confirm
    val r3 = decider.decide(RallyEnd(Pt(3.0, 13.4), Side.A, Side.B, false, 0.9))
    check("on line -> needs confirm", r3 is PointDecision.NeedsConfirm)
    // no landing -> needs confirm, no suggestion
    val r4 = decider.decide(RallyEnd(null, Side.A, Side.B, false, 0.9))
    check("no landing -> confirm, no suggestion", r4 is PointDecision.NeedsConfirm && r4.suggested == null)
    println("ALL PASSED")
}
